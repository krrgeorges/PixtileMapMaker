Cipitillo
https://www.dafont.com/cipitillo.font