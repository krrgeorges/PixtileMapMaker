For more details see silveiraneto.net/tag/pixelart

GETTING OPENPIXELS
===============================================================================
See http://silveiraneto.net/2011/08/20/getting-openpixels/

LAYERS
===============================================================================
On the open_chars.xcf file each layer should have a name like:
	TYPE_DESCRIPTION

Examples:
	hair_cuttedblack
	cloths_dress

Right now no spaces are allowed.

To extract xcf layers into png files first install the package xcftools.
Exemple:
	sudo apt-get install xcftools

After this execute the script extract_layers.sh to the xcf file.
	./extract_layers open_chars.xcf


--
--